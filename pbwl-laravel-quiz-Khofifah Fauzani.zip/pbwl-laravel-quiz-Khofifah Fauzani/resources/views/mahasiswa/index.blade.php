@extends('layouts.app')

@section('content')

<h2>Mahasiswa</h2>

@endsection