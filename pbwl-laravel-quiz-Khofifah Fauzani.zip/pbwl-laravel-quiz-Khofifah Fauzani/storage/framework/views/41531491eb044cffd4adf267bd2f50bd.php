

<?php $__env->startSection('content'); ?>

<h2>Mahasiswa</h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl-laravel2\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>